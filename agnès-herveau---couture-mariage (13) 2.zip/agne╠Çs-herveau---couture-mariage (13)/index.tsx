// Le site a été converti en une version statique classique (HTML/CSS/JS) dans index.html.
// Ce fichier n'est plus utilisé pour le rendu.
console.log("Mode site statique activé.");